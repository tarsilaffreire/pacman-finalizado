import math
import pygame
from constants import *
import numpy as np
from animation import Animator

BASETILEWIDTH = 16
BASETILEHEIGHT = 16
DEATH = 5

class Spritesheet(object):
    _cache = None   # a folha e carregada/escalada uma unica vez e compartilhada

    def __init__(self):
        if Spritesheet._cache is None:
            sheet = pygame.image.load("spritesheet.png").convert()
            transcolor = sheet.get_at((0,0))
            sheet.set_colorkey(transcolor)
            width = int(sheet.get_width() / BASETILEWIDTH * TILEWIDTH)
            height = int(sheet.get_height() / BASETILEHEIGHT * TILEHEIGHT)
            Spritesheet._cache = pygame.transform.scale(sheet, (width, height))
        self.sheet = Spritesheet._cache
        
    def getImage(self, x, y, width, height):
        x *= TILEWIDTH
        y *= TILEHEIGHT
        self.sheet.set_clip(pygame.Rect(x, y, width, height))
        return self.sheet.subsurface(self.sheet.get_clip())
    

class PacmanSprites(Spritesheet):
    def __init__(self, entity):
        Spritesheet.__init__(self)
        self.entity = entity
        self.entity.image = self.getStartImage()  
        self.animations = {}
        self.defineAnimations()
        self.stopimage = (8, 0)     

    def getStartImage(self):
        return self.getImage(8, 0)

    def getImage(self, x, y):
        return Spritesheet.getImage(self, x, y, 2*TILEWIDTH, 2*TILEHEIGHT)
    
    def defineAnimations(self):
        self.animations[LEFT] = Animator(((8,0), (0, 0), (0, 2), (0, 0)))
        self.animations[RIGHT] = Animator(((10,0), (2, 0), (2, 2), (2, 0)))
        self.animations[UP] = Animator(((10,2), (6, 0), (6, 2), (6, 0)))
        self.animations[DOWN] = Animator(((8,2), (4, 0), (4, 2), (4, 0)))
        self.animations[DEATH] = Animator(((0, 12), (2, 12), (4, 12), (6, 12), (8, 12), (10, 12), (12, 12), (14, 12), (16, 12), (18, 12), (20, 12)), speed=6, loop=False)

    def update(self, dt):
        if self.entity.alive == True:
            if self.entity.direction == LEFT:
                self.entity.image = self.getImage(*self.animations[LEFT].update(dt))
                self.stopimage = (8, 0)
            elif self.entity.direction == RIGHT:
                self.entity.image = self.getImage(*self.animations[RIGHT].update(dt))
                self.stopimage = (10, 0)
            elif self.entity.direction == DOWN:
                self.entity.image = self.getImage(*self.animations[DOWN].update(dt))
                self.stopimage = (8, 2)
            elif self.entity.direction == UP:
                self.entity.image = self.getImage(*self.animations[UP].update(dt))
                self.stopimage = (10, 2)
            elif self.entity.direction == STOP:
                self.entity.image = self.getImage(*self.stopimage)
        else:
           self.entity.image = self.getImage(*self.animations[DEATH].update(dt))
           
    def reset(self):
        for key in list(self.animations.keys()):
            self.animations[key].reset()

class MsPacmanSprites(PacmanSprites):

    
    FRAME_DIRECTIONS = {(8,0):LEFT, (0,0):LEFT, (0,2):LEFT,
                        (10,0):RIGHT, (2,0):RIGHT, (2,2):RIGHT,
                        (10,2):UP, (6,0):UP, (6,2):UP,
                        (8,2):DOWN, (4,0):DOWN, (4,2):DOWN}
    
    BOW_OFFSETS = {RIGHT:(-6,-10), LEFT:(6,-10), UP:(-10,6), DOWN:(10,-6)}

    def __init__(self, entity):
        self.bowCache = {}
        PacmanSprites.__init__(self, entity)

    def getImage(self, x, y):
        key = (x, y)
        if key not in self.bowCache:
            base = PacmanSprites.getImage(self, x, y)
            image = base.copy()
            if y == 12:                      # animacao de morte aq
                self.drawDeathBow(image, x // 2)
            else:
                direction = self.FRAME_DIRECTIONS.get(key, LEFT)
                ox, oy = self.BOW_OFFSETS[direction]
                self.drawBow(image, ox, oy, 1.0)
            self.bowCache[key] = image
        return self.bowCache[key]

    def drawDeathBow(self, image, frame):
        if frame > 8:
            return
        angle = frame * math.pi / 4.0
        ox, oy = self.BOW_OFFSETS[RIGHT]
        rx = ox * math.cos(angle) - oy * math.sin(angle)
        ry = ox * math.sin(angle) + oy * math.cos(angle)
        shrink = max(0.35, 1.0 - frame * 0.08)
        self.drawBow(image, rx * shrink, ry * shrink, shrink)

    def drawBow(self, image, ox, oy, scale):
        s = TILEWIDTH / 16.0
        cx = image.get_width() / 2.0 + ox * s
        cy = image.get_height() / 2.0 + oy * s
        length = math.sqrt(ox * ox + oy * oy) or 1.0
        rx, ry = ox / length, oy / length      
        tx, ty = -ry, rx                         
        loop = 7.0 * s * scale                    
        half = 3.8 * s * scale                     
        fill = (235, 25, 45)
        edge = (120, 0, 15)
        for side in (1, -1):
            tip_x = cx + tx * loop * side
            tip_y = cy + ty * loop * side
            pts = [(int(round(cx)), int(round(cy))),
                   (int(round(tip_x + rx * half)), int(round(tip_y + ry * half))),
                   (int(round(tip_x - rx * half)), int(round(tip_y - ry * half)))]
            pygame.draw.polygon(image, fill, pts)
            pygame.draw.polygon(image, edge, pts, 1)
        knot = max(1, int(round(2.6 * s * scale)))
        pygame.draw.circle(image, (255, 90, 110), (int(cx), int(cy)), knot)
        pygame.draw.circle(image, edge, (int(cx), int(cy)), knot, 1)


class GhostSprites(Spritesheet):
    def __init__(self, entity):
        Spritesheet.__init__(self)
        self.x = {BLINKY:0, PINKY:2, INKY:4, CLYDE:6}
        self.entity = entity
        self.entity.image = self.getStartImage()
               
    def getStartImage(self):
        return self.getImage(self.x[self.entity.name], 4)

    def getImage(self, x, y):
        return Spritesheet.getImage(self, x, y, 2*TILEWIDTH, 2*TILEHEIGHT)
    
    def update(self, dt):
        x = self.x[self.entity.name]
        if self.entity.mode.current in [SCATTER, CHASE]:
            if self.entity.direction == LEFT:
                self.entity.image = self.getImage(x, 8)
            elif self.entity.direction == RIGHT:
                self.entity.image = self.getImage(x, 10)
            elif self.entity.direction == DOWN:
                self.entity.image = self.getImage(x, 6)
            elif self.entity.direction == UP:
                self.entity.image = self.getImage(x, 4)
        elif self.entity.mode.current == FREIGHT:
            self.entity.image = self.getImage(10, 4)
        elif self.entity.mode.current == SPAWN:
            if self.entity.direction == LEFT:
                self.entity.image = self.getImage(8, 8)
            elif self.entity.direction == RIGHT:
                self.entity.image = self.getImage(8, 10)
            elif self.entity.direction == DOWN:
                self.entity.image = self.getImage(8, 6)
            elif self.entity.direction == UP:
               self.entity.image = self.getImage(8, 4)


class FruitSprites(Spritesheet):
    def __init__(self, entity):
        Spritesheet.__init__(self)
        self.entity = entity
        self.entity.image = self.getStartImage()

    def getStartImage(self):
        return self.getImage(16, 8)

    def getImage(self, x, y):
        return Spritesheet.getImage(self, x, y, 2*TILEWIDTH, 2*TILEHEIGHT)
    

class LifeSprites(Spritesheet):
    def __init__(self, numlives):
        Spritesheet.__init__(self)
        self.resetLives(numlives)

    def removeImage(self):
        if len(self.images) > 0:
            self.images.pop(0)

    def resetLives(self, numlives):
        self.images = []
        for i in range(numlives):
            self.images.append(self.getImage(0,0))

    def getImage(self, x, y):
        return Spritesheet.getImage(self, x, y, 2*TILEWIDTH, 2*TILEHEIGHT)
    

class MazeSprites(Spritesheet):
    def __init__(self, mazefile, rotfile):
        Spritesheet.__init__(self)
        self.data = self.readMazeFile(mazefile)
        self.rotdata = self.readMazeFile(rotfile)

    def getImage(self, x, y):
        return Spritesheet.getImage(self, x, y, TILEWIDTH, TILEHEIGHT)

    def readMazeFile(self, mazefile):
        return np.loadtxt(mazefile, dtype='<U1')

    def constructBackground(self, background, y):
        for row in list(range(self.data.shape[0])):
            for col in list(range(self.data.shape[1])):
                if self.data[row][col].isdigit():
                    x = int(self.data[row][col]) + 12
                    sprite = self.getImage(x, y)
                    rotval = int(self.rotdata[row][col])
                    sprite = self.rotate(sprite, rotval)
                    background.blit(sprite, (col*TILEWIDTH, row*TILEHEIGHT))
                elif self.data[row][col] == '=':
                    sprite = self.getImage(10, 8)
                    background.blit(sprite, (col*TILEWIDTH, row*TILEHEIGHT))

        return background
    
    def rotate(self, sprite, value):
       return pygame.transform.rotate(sprite, value*90)