
import pygame
from pygame.locals import *
from constants import *
from config import *
from pacman import Pacman, DEFAULT_CONTROLS
from nodes import NodeGroup
from pellets import PelletGroup
from ghosts import GhostGroup
from fruit import Fruit
from pauser import Pause
from text import TextGroup
from sprites import MazeSprites
from powerups import PowerUpManager


P1_CONTROLS = DEFAULT_CONTROLS
P2_CONTROLS = {UP:[K_w], DOWN:[K_s], LEFT:[K_a], RIGHT:[K_d]}
SOLO_CONTROLS = {UP:[K_UP, K_w], DOWN:[K_DOWN, K_s], LEFT:[K_LEFT, K_a], RIGHT:[K_RIGHT, K_d]}


SOLO_START = [((15, 26), LEFT)]                        # igual ao jogo original
COOP_START = [((15, 26), RIGHT), ((12, 26), LEFT)]     # um para cada lado


class PlayerSlot(object):
  
    def __init__(self, playerId, name, character, controls):
        self.playerId = playerId
        self.name = name
        self.character = character
        self.controls = controls


class GameWorld(object):
    def __init__(self, slots, autoRestart=False, individualRespawn=None):
        self.slots = slots
        self.autoRestart = autoRestart  

        # morte/respawn sem pausar o jogo: ligado no coop e no split (cada jogador renasce sozinho,
        # os fantasmas nao sao reiniciados). so o solo mantem a pausa global do jogo original.

        if individualRespawn is None:
            individualRespawn = len(slots) > 1
        self.individualRespawn = individualRespawn
        self.surface = pygame.Surface(SCREENSIZE).convert()
        self.background = None
        self.fruit = None
        self.fruitSpawned = set()
        self.pause = Pause(True)
        self.level = 0
        self.score = 0                   
        self.textgroup = TextGroup()
        self.players = []
        self.userPaused = False
        self.finished = False
        self.freezeTimer = 0.0
        self.freezeOwner = None
        self.messages = {}                  
        self.powerups = PowerUpManager("maze1.txt")


    @property
    def pacman(self):
        return self.players[0]

    def activePlayers(self):
        return [p for p in self.players if not p.eliminated and not p.pendingOut]


    def restartGame(self):
        self.level = 0
        self.pause.paused = True
        self.pause.pauseTime = None
        self.fruit = None
        self.finished = False
        self.players = []                  
        self.startGame()
        self.score = 0
        self.textgroup.updateScore(self.score)
        self.textgroup.updateLevel(self.level)
        self.textgroup.showText(READYTXT)

    def resetLevel(self):
        self.pause.paused = True
        for p in self.players:
            if p.pendingOut:
                p.pendingOut = False
                p.eliminated = True
                p.visible = False
            elif not p.eliminated and not p.alive:
                p.reset()
        self.ghosts.reset()
        self.fruit = None
        self.clearEffects()
        self.textgroup.showText(READYTXT)

    def nextLevel(self):
        self.showEntities()
        self.level += 1
        self.pause.paused = True
        self.startGame()
        self.textgroup.updateLevel(self.level)

    def setBackground(self):
        self.background = pygame.surface.Surface(SCREENSIZE).convert()
        self.background.fill(BLACK)

    def startGame(self):
        self.setBackground()
        self.mazesprites = MazeSprites("maze1.txt", "maze1_rotation.txt")
        self.background = self.mazesprites.constructBackground(self.background, self.level%5)
        self.nodes = NodeGroup("maze1.txt")
        self.nodes.setPortalPair((0,17), (27,17))
        homekey = self.nodes.createHomeNodes(11.5, 14)
        self.nodes.connectHomeNodes(homekey, (12,14), LEFT)
        self.nodes.connectHomeNodes(homekey, (15,14), RIGHT)
        self.placePlayers()
        self.pellets = PelletGroup("maze1.txt")
        self.fruit = None
        self.fruitSpawned = set()
        self.ghosts = GhostGroup(self.nodes.getStartTempNode(), self.players, self.level)
        self.ghosts.setPelletGroup(self.pellets)
        self.ghosts.blinky.setStartNode(self.nodes.getNodeFromTiles(2+11.5, 0+14))
        self.ghosts.pinky.setStartNode(self.nodes.getNodeFromTiles(2+11.5, 3+14))
        self.ghosts.inky.setStartNode(self.nodes.getNodeFromTiles(0+11.5, 3+14))
        self.ghosts.clyde.setStartNode(self.nodes.getNodeFromTiles(4+11.5, 3+14))
        self.ghosts.setSpawnNode(self.nodes.getNodeFromTiles(2+11.5, 3+14))
        for p in self.players:
            self.nodes.denyHomeAccess(p)
        self.nodes.denyHomeAccessList(self.ghosts)
        self.nodes.denyAccessList(2+11.5, 3+14, LEFT, self.ghosts)
        self.nodes.denyAccessList(2+11.5, 3+14, RIGHT, self.ghosts)
        self.ghosts.inky.startNode.denyAccess(RIGHT, self.ghosts.inky)
        self.ghosts.clyde.startNode.denyAccess(LEFT, self.ghosts.clyde)
        self.nodes.denyAccessList(12, 14, UP, self.ghosts)
        self.nodes.denyAccessList(15, 14, UP, self.ghosts)
        self.nodes.denyAccessList(12, 26, UP, self.ghosts)
        self.nodes.denyAccessList(15, 26, UP, self.ghosts)
        self.powerups.reset()
        self.freezeTimer = 0.0
        self.freezeOwner = None

    def placePlayers(self):

        starts = COOP_START if len(self.slots) > 1 else SOLO_START
        if not self.players:
            for i, slot in enumerate(self.slots):
                tile, direction = starts[i]
                node = self.nodes.getNodeFromTiles(*tile)
                p = Pacman(node, controls=slot.controls, character=slot.character,
                           playerId=slot.playerId, startDirection=direction)
                p.playerName = slot.name
                self.players.append(p)
        else:
            for i, p in enumerate(self.players):
                tile, direction = starts[i]
                p.setStartNode(self.nodes.getNodeFromTiles(*tile))
                if p.pendingOut:                    # morreu sem vidas bem na virada de nivel
                    p.pendingOut = False
                    p.eliminated = True
                    p.visible = False
                if not p.eliminated:
                    p.reset()

   
    def update(self, dt):
        self.textgroup.update(dt)
        self.pellets.update(dt)
        if self.finished or self.userPaused:
            return
        if not self.pause.paused:
            self.updateFreeze(dt)
            self.ghosts.update(dt)
            if self.fruit is not None:
                self.fruit.update(dt)
            self.powerups.update(dt)
            self.checkPelletEvents()
            self.checkGhostEvents()
            self.checkFruitEvents()
            self.checkPowerUpEvents()

        for p in self.players:
            if p.eliminated:
                continue
            if p.alive:
                if not self.pause.paused:
                    p.update(dt)
            else:
                p.update(dt)            # animacao de morte
                if self.individualRespawn:
                    self.updateRespawn(p, dt)

        afterPauseMethod = self.pause.update(dt)
        if afterPauseMethod is not None:
            afterPauseMethod()
        self.updateMessages(dt)

    def updateScore(self, points, player=None):
        self.score += points
        if player is not None:
            player.score += points
        self.textgroup.updateScore(self.score)


  
  
    def isWaiting(self):
        
        return (self.pause.paused and self.pause.pauseTime is None
                and not self.finished and not self.userPaused)

    def isTimedPause(self):
        return self.pause.pauseTime is not None

    def resume(self):
        self.pause.paused = False
        self.textgroup.hideText()
        self.showEntities()

    def setUserPaused(self, flag):
        if self.finished or self.isTimedPause() or self.isWaiting():
            return
        self.userPaused = flag
        if flag:
            self.textgroup.showText(PAUSETXT)
            self.hideEntities()
        else:
            self.textgroup.hideText()
            self.showEntities()


    def checkPelletEvents(self):
        for p in self.activePlayers():
            if not p.alive:
                continue
            pellet = p.eatPellets(self.pellets.pelletList)
            if pellet:
                self.pellets.numEaten += 1
                self.updateScore(pellet.points, p)
                if self.pellets.numEaten == 30:
                    self.ghosts.inky.startNode.allowAccess(RIGHT, self.ghosts.inky)
                if self.pellets.numEaten == 70:
                    self.ghosts.clyde.startNode.allowAccess(LEFT, self.ghosts.clyde)
                self.pellets.pelletList.remove(pellet)
                if pellet.name == POWERPELLET:
                   self.ghosts.startFreight()
                self.powerups.onPelletEaten(self.activePlayers())
                if self.pellets.isEmpty():
                    self.hideEntities()
                    self.pause.startTimed(3, self.nextLevel)
                    return

    def checkGhostEvents(self):
        if self.pause.paused:
            return
        hits = []
        for p in self.activePlayers():
            if not p.alive:
                continue
            for ghost in self.ghosts:
                if p.collideGhost(ghost):
                    if ghost.mode.current is FREIGHT:
                        p.visible = False
                        ghost.visible = False
                        self.updateScore(ghost.points, p)
                        self.textgroup.addText(str(ghost.points), WHITE, ghost.position.x, ghost.position.y, 8, time=1)
                        self.ghosts.updatePoints()
                        self.pause.startTimed(1, self.showEntities)
                        ghost.startSpawn()
                        self.nodes.allowHomeAccess(ghost)
                        return
                    elif ghost.mode.current is not SPAWN and not ghost.frozen:
                        if p not in hits:
                            hits.append(p)
        if hits:
            self.playersHit(hits)

    def playersHit(self, hits):
        for p in hits:
            p.lives -= 1
            p.die()
            if p.lives <= 0:
                p.lives = 0
                p.pendingOut = True
            self.setMessage(p, "-1 VIDA", RED)
            if self.individualRespawn:
                p.respawnTimer = PLAYER_RESPAWN_DELAY   # temporizador proprio de cada jogador
        if self.individualRespawn:
            # Coop: sem pausa global e sem tocar nos fantasmas. Os fantasmas so param
            # (GAME OVER) quando NENHUM jogador tem mais vidas.
            if all(p.lives <= 0 for p in self.players):
                self.ghosts.hide()
                self.textgroup.showText(GAMEOVERTXT)
                self.pause.startTimed(3, self.onGameOver)
            return
        self.ghosts.hide()
        if all(p.lives <= 0 for p in self.players):
            self.textgroup.showText(GAMEOVERTXT)
            self.pause.startTimed(3, self.onGameOver)
        else:
            self.pause.startTimed(3, self.resetLevel)

    def updateRespawn(self, p, dt):
        # Coop: conta o tempo de UM jogador morto e o faz renascer sozinho.
        if p.respawnTimer <= 0:
            return
        p.respawnTimer -= dt
        if p.respawnTimer <= 0:
            p.respawnTimer = 0.0
            if p.pendingOut:                        # acabaram as vidas: sai da partida
                p.pendingOut = False
                p.eliminated = True
                p.visible = False
            else:
                p.respawn()                         # volta na posicao/direcao inicial

    def onGameOver(self):
        if self.autoRestart:
            self.restartGame()              # modo solo: igual ao jogo original
        else:
            self.finished = True
            self.pause.paused = True
            self.hideEntities()
            self.textgroup.showText(GAMEOVERTXT)

    def checkFruitEvents(self):
        if self.pause.paused:
            return
        for threshold in (50, 140):
            if self.pellets.numEaten == threshold and threshold not in self.fruitSpawned:
                if self.fruit is None:
                    self.fruitSpawned.add(threshold)
                    self.fruit = Fruit(self.nodes.getNodeFromTiles(9, 20))
        if self.fruit is not None:
            for p in self.activePlayers():
                if p.alive and p.collideCheck(self.fruit):
                    self.updateScore(self.fruit.points, p)
                    self.textgroup.addText(str(self.fruit.points), WHITE, self.fruit.position.x, self.fruit.position.y, 8, time=1)
                    self.fruit = None
                    break
            if self.fruit is not None and self.fruit.destroy:
                self.fruit = None

    def checkPowerUpEvents(self):
        if self.pause.paused:
            return
        for item in list(self.powerups.items):
            for p in self.activePlayers():
                if p.alive and p.collideCheck(item):
                    self.collectPowerUp(p, item)
                    break


    def collectPowerUp(self, player, item):
        self.powerups.remove(item)
        if item.kind == HEART_ITEM:
            before = player.lives
            player.lives = min(MAX_LIVES, player.lives + HEART_LIVES_GAINED)
            if player.lives > before:
                self.setMessage(player, "+%d VIDA" % (player.lives - before), (255, 80, 100))
                label = "+1UP"
            else:
                self.setMessage(player, "VIDA CHEIA", WHITE)
                label = "MAX"
            self.textgroup.addText(label, (255, 80, 100), item.position.x, item.position.y, 8, time=1)
        elif item.kind == FREEZE_ITEM:
            self.activateFreeze(player)
            self.setMessage(player, "CONGELOU!", ICE_BLUE)
            self.textgroup.addText("FREEZE", ICE_BLUE, item.position.x - 8, item.position.y, 8, time=1)
        extra = POWERUP_POINTS.get(item.kind, 0)
        if extra:
            self.updateScore(extra, player)

    def activateFreeze(self, player):
        self.freezeTimer = FREEZE_DURATION  
        self.freezeOwner = player
        self.ghosts.setFrozen(True)

    def updateFreeze(self, dt):
        if self.freezeTimer > 0:
            self.freezeTimer -= dt
            if self.freezeTimer <= 0:
                self.freezeTimer = 0.0
                self.freezeOwner = None
                self.ghosts.setFrozen(False)

    def clearEffects(self):
        self.freezeTimer = 0.0
        self.freezeOwner = None
        self.ghosts.setFrozen(False)
        self.powerups.clear()


    def setMessage(self, player, text, color):
        self.messages[player.playerId] = [text, color, HUD_MESSAGE_TIME]

    def updateMessages(self, dt):
        for pid in list(self.messages.keys()):
            self.messages[pid][2] -= dt
            if self.messages[pid][2] <= 0:
                del self.messages[pid]


    def showEntities(self):
        for p in self.players:
            p.visible = not p.eliminated
        self.ghosts.show()

    def hideEntities(self):
        for p in self.players:
            p.visible = False
        self.ghosts.hide()

    def render(self):
        s = self.surface
        s.blit(self.background, (0, 0))
        self.pellets.render(s)
        self.powerups.render(s)
        if self.fruit is not None:
            self.fruit.render(s)
        for p in self.players:
            if not p.eliminated:
                p.render(s)
        self.ghosts.render(s)
        self.textgroup.render(s)
        return s
