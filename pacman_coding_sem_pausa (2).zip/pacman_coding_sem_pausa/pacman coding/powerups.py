
import math
import random
import numpy as np
import pygame
from pygame.locals import *
from vector import Vector2
from constants import *
from config import *


class PowerUpArt(object):
    _cache = {}

    @classmethod
    def get(cls, kind):
        if kind not in cls._cache:
            size = 2 * TILEWIDTH
            surf = pygame.Surface((size, size), SRCALPHA)
            if kind == HEART_ITEM:
                cls.drawHeart(surf)
            else:
                cls.drawSnowflake(surf)
            cls._cache[kind] = surf
        return cls._cache[kind]

    @staticmethod
    def drawHeart(surf):
        s = surf.get_width() / 32.0
        def P(x, y):
            return (int(x * s), int(y * s))
        dark = (110, 0, 20)
        red = (235, 20, 50)
        # contorno (formas ligeiramente maiores)
        pygame.draw.circle(surf, dark, P(11, 13), int(7.5 * s))
        pygame.draw.circle(surf, dark, P(21, 13), int(7.5 * s))
        pygame.draw.polygon(surf, dark, [P(4, 15), P(28, 15), P(16, 29.5)])
        # preenchimento
        pygame.draw.circle(surf, red, P(11, 13), int(6 * s))
        pygame.draw.circle(surf, red, P(21, 13), int(6 * s))
        pygame.draw.polygon(surf, red, [P(5.5, 15.5), P(26.5, 15.5), P(16, 27)])
        # brilho
        pygame.draw.circle(surf, (255, 170, 180), P(9, 10), max(1, int(2 * s)))

    @staticmethod
    def drawSnowflake(surf):
        s = surf.get_width() / 32.0
        c = surf.get_width() / 2.0
        blue = (90, 190, 255)
        white = (225, 245, 255)
        pygame.draw.circle(surf, (20, 50, 120, 150), (int(c), int(c)), int(14 * s))
        pygame.draw.circle(surf, (60, 140, 230), (int(c), int(c)), int(14 * s), 1)
        radius = 11.0 * s
        for i in range(6):
            a = math.radians(60 * i)
            ex, ey = c + math.cos(a) * radius, c + math.sin(a) * radius
            pygame.draw.line(surf, blue, (c, c), (ex, ey), max(1, int(2 * s)))
            # pequenos "galhos" perto da ponta de cada raio
            bx, by = c + math.cos(a) * radius * 0.62, c + math.sin(a) * radius * 0.62
            for off in (-40, 40):
                b = math.radians(60 * i + off)
                pygame.draw.line(surf, white, (bx, by),
                                 (bx + math.cos(b) * 4.2 * s, by + math.sin(b) * 4.2 * s), 1)
        pygame.draw.circle(surf, white, (int(c), int(c)), max(1, int(2 * s)))


class PowerUpItem(object):
    def __init__(self, kind, position, lifetime=POWERUP_LIFETIME):
        self.name = kind
        self.kind = kind
        self.position = position
        self.collideRadius = 6
        self.lifetime = lifetime
        self.timer = 0.0
        self.visible = True
        self.destroy = False

    @property
    def remaining(self):
        return max(0.0, self.lifetime - self.timer)

    def update(self, dt):
        self.timer += dt
        if self.timer >= self.lifetime:
            self.destroy = True
        
        if self.remaining <= POWERUP_BLINK_TIME:
            self.visible = int(self.timer * 6) % 2 == 0
        else:
            self.visible = True

    def render(self, screen):
        if not self.visible:
            return
        image = PowerUpArt.get(self.kind)
        bob = math.sin(self.timer * 5.0) * 1.5      
        adjust = Vector2(TILEWIDTH, TILEHEIGHT) / 2
        p = self.position + adjust
        screen.blit(image, (p.x - image.get_width() / 2, p.y - image.get_height() / 2 + bob))


class PowerUpManager(object):
    
    def __init__(self, mazefile="maze1.txt", rng=None):
        self.rng = rng if rng is not None else random
        self.items = []
        self.cooldown = 0.0
        self.spawnTiles = self.buildSpawnTiles(mazefile)

    @staticmethod
    def buildSpawnTiles(mazefile):
        data = np.loadtxt(mazefile, dtype='<U1')
        tiles = []
        for row in range(data.shape[0]):
            for col in range(data.shape[1]):
                if data[row][col] not in ['.', '+', '-', '|']:
                    continue                    
                if 9 <= col <= 18 and 12 <= row <= 19:
                    continue                      
                if row == 17:
                    continue                      
                tiles.append((col, row))
        return tiles

    def reset(self):
        self.items = []
        self.cooldown = 0.0

    def clear(self):
        self.items = []

    def update(self, dt):
        if self.cooldown > 0:
            self.cooldown -= dt
        for item in self.items:
            item.update(dt)
        self.items = [item for item in self.items if not item.destroy]

    def remove(self, item):
        if item in self.items:
            self.items.remove(item)

    def onPelletEaten(self, players=()):

        if self.cooldown > 0 or len(self.items) >= POWERUP_MAX_ACTIVE:
            return None
        if self.rng.random() >= POWERUP_SPAWN_CHANCE:
            return None
        kinds = list(POWERUP_TYPE_WEIGHTS.keys())
        weights = [POWERUP_TYPE_WEIGHTS[k] for k in kinds]
        kind = self.rng.choices(kinds, weights=weights, k=1)[0]
        return self.spawn(kind, players)

    def spawn(self, kind, players=()):
        position = self.pickPosition(players)
        if position is None:
            return None
        item = PowerUpItem(kind, position, POWERUP_LIFETIME)
        self.items.append(item)
        self.cooldown = POWERUP_MIN_INTERVAL
        return item

    def pickPosition(self, players=()):
        itemDist2 = (POWERUP_MIN_ITEM_DISTANCE * TILEWIDTH) ** 2
        playerDist2 = (POWERUP_MIN_PLAYER_DISTANCE * TILEWIDTH) ** 2
        free = []
        for col, row in self.spawnTiles:
            pos = Vector2(col * TILEWIDTH, row * TILEHEIGHT)
            if any((pos - it.position).magnitudeSquared() < itemDist2 for it in self.items):
                continue
            if any((pos - p.position).magnitudeSquared() < playerDist2 for p in players):
                continue
            free.append(pos)
        if not free:
            return None
        return self.rng.choice(free)

    def render(self, screen):
        for item in self.items:
            item.render(screen)
