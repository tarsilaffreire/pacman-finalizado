import random
from collections import deque
import pygame
from pygame.locals import *
from vector import Vector2
from constants import *
from config import *
from entity import Entity
from modes import ModeController
from sprites import GhostSprites


class Ghost(Entity):

    DIRECTION_PRIORITY = [UP, LEFT, DOWN, RIGHT]
    _iceOverlay = None

    def __init__(self, node, pacman=None, blinky=None, level=0):
        Entity.__init__(self, node)
        self.name = GHOST
        self.points = 200
        self.goal = Vector2()
        self.pacman = pacman             
        self.players = [pacman] if pacman is not None else []
        self.level = level
        self.mode = ModeController(self, level)
        self.blinky = blinky
        self.homeNode = node
        self.frozen = False             
        self.pelletGroup = None
        self.targetTimer = 0
        self.history = deque(maxlen=LOOP_HISTORY)  
        self.loopCooldown = 0
        self.lastMainMode = self.mode.mainmode.mode

    def update(self, dt):
        self.sprites.update(dt)
        if self.frozen:
            return
        self.mode.update(dt)
        self.selectTarget(dt)
        self.checkModeSwitch()
        if self.loopCooldown > 0:
            self.loopCooldown -= dt
        if self.mode.current is SCATTER:
            self.scatter()
        elif self.mode.current is CHASE:
            self.chase()
        Entity.update(self, dt)

    def reset(self):
        Entity.reset(self)
        self.points = 200
        self.directionMethod = self.goalDirection
        self.setSpeed(self.normalSpeed())
        self.history.clear()

    def normalSpeed(self):
        return 100

    def setPlayers(self, players):
        self.players = list(players)
        if self.players:
            self.pacman = self.players[0]

    def setPelletGroup(self, pelletGroup):
        self.pelletGroup = pelletGroup

    def setFrozen(self, frozen):
        self.frozen = frozen


    def candidates(self):
        alive = [p for p in self.players if p.alive and not p.eliminated]
        if alive:
            return alive
        remaining = [p for p in self.players if not p.eliminated]
        return remaining if remaining else self.players

    def lifeFactor(self, player):
        return 1.0 + TARGET_LIFE_WEIGHT * max(0, player.lives - 1)

    def targetScore(self, player):
        d = (player.position - self.position).magnitude()
        return d * self.lifeFactor(player)

    def selectTarget(self, dt):
        cands = self.candidates()
        if not cands:
            return
        if len(cands) == 1:
            self.pacman = cands[0]
            return
        self.targetTimer -= dt
        if self.targetTimer > 0 and self.pacman in cands:
            return
        self.targetTimer = TARGET_RECHECK_TIME
        best = min(cands, key=self.targetScore)
        if self.pacman in cands and best is not self.pacman:
            current = self.targetScore(self.pacman)
            if current > 0 and self.targetScore(best) > current * TARGET_SWITCH_MARGIN:
                best = self.pacman
        self.pacman = best

    def insideHouse(self):
        x, y = self.position.x, self.position.y
        return (11.4*TILEWIDTH <= x <= 15.6*TILEWIDTH) and (14*TILEHEIGHT + 1 < y <= 18.5*TILEHEIGHT)

    def checkModeSwitch(self):
        """Como no jogo classico: ao trocar SCATTER<->CHASE o fantasma inverte o sentido."""
        current = self.mode.mainmode.mode
        if current != self.lastMainMode:
            self.lastMainMode = current
            if self.mode.current in (SCATTER, CHASE) and self.direction != STOP and not self.insideHouse():
                self.reverseDirection()

    def scatter(self):
        tx, ty = SCATTER_TARGETS.get(self.name, (0, 0))
        self.goal = Vector2(tx*TILEWIDTH, ty*TILEHEIGHT)

    def chase(self):
        self.goal = self.pacman.position.copy()

    def pointAhead(self, tiles):
        """Ponto 'tiles' casas a frente do jogador alvo, dentro dos limites do mapa."""
        p = self.pacman
        point = p.position + p.directions[p.heading] * (TILEWIDTH * tiles)
        x = min(max(point.x, 0), NCOLS*TILEWIDTH)
        y = min(max(point.y, 0), NROWS*TILEHEIGHT)
        return Vector2(x, y)

    def startFreight(self):
        self.mode.setFreightMode()
        if self.mode.current == FREIGHT:
            self.setSpeed(50)
            self.directionMethod = self.randomDirection         

    def normalMode(self):
        self.setSpeed(self.normalSpeed())
        self.directionMethod = self.goalDirection
        self.homeNode.denyAccess(DOWN, self)

    def spawn(self):
        self.goal = self.spawnNode.position

    def setSpawnNode(self, node):
        self.spawnNode = node

    def startSpawn(self):
        self.mode.setSpawnMode()
        if self.mode.current == SPAWN:
            self.setSpeed(150)
            self.directionMethod = self.goalDirection
            self.spawn()

    def goalDirection(self, directions):
        best = None
        bestDistance = None
        for direction in self.DIRECTION_PRIORITY:
            if direction in directions:
                vec = self.node.position + self.directions[direction]*TILEWIDTH - self.goal
                distance = vec.magnitudeSquared()
                if bestDistance is None or distance < bestDistance:
                    best = direction
                    bestDistance = distance
        if best is None:
            best = directions[0]
        return self.breakLoop(directions, best)

    def breakLoop(self, directions, choice):
        self.history.append(self.node)
        if (self.mode.current is CHASE and self.loopCooldown <= 0
                and len(self.history) == self.history.maxlen
                and len(set(self.history)) <= LOOP_MAX_UNIQUE_NODES
                and len(directions) > 1):
            others = [d for d in directions if d != choice]
            self.history.clear()
            self.loopCooldown = LOOP_COOLDOWN
            return random.choice(others)
        return choice

    @classmethod
    def iceOverlay(cls):
        if cls._iceOverlay is None:
            size = 2 * TILEWIDTH
            surf = pygame.Surface((size, size), SRCALPHA)
            c = size // 2
            pygame.draw.circle(surf, (120, 200, 255, 85), (c, c), int(c * 0.85))
            pygame.draw.circle(surf, (200, 235, 255, 230), (c, c), int(c * 0.85), 2)
            cls._iceOverlay = surf
        return cls._iceOverlay

    def render(self, screen):
        Entity.render(self, screen)
        if self.frozen and self.visible:
            overlay = self.iceOverlay()
            adjust = Vector2(TILEWIDTH, TILEHEIGHT) / 2
            p = self.position + adjust
            screen.blit(overlay, (p.x - overlay.get_width() / 2, p.y - overlay.get_height() / 2))


class Blinky(Ghost):
    def __init__(self, node, pacman=None, blinky=None, level=0):
        Ghost.__init__(self, node, pacman, blinky, level)
        self.name = BLINKY
        self.color = RED
        self.sprites = GhostSprites(self)

    def pelletsRemaining(self):
        if self.pelletGroup is None:
            return 10**6
        return len(self.pelletGroup.pelletList)

    def elroyBonus(self):
        remaining = self.pelletsRemaining()
        if remaining <= BLINKY_ELROY_2_PELLETS:
            return BLINKY_ELROY_2_BONUS
        if remaining <= BLINKY_ELROY_1_PELLETS:
            return BLINKY_ELROY_1_BONUS
        return 0.0

    def isElroy(self):
        return self.pelletsRemaining() <= BLINKY_ELROY_1_PELLETS

    def normalSpeed(self):
        levelBonus = min(BLINKY_MAX_LEVEL_BONUS, self.level * BLINKY_SPEED_BONUS_PER_LEVEL)
        return 100 * (1.0 + levelBonus + self.elroyBonus())

    def update(self, dt):
        if not self.frozen and self.mode.current in (SCATTER, CHASE):
            self.setSpeed(self.normalSpeed())
        Ghost.update(self, dt)

    def scatter(self):
        if self.isElroy():
            self.chase()      
        else:
            Ghost.scatter(self)


class Pinky(Ghost):
    def __init__(self, node, pacman=None, blinky=None, level=0):
        Ghost.__init__(self, node, pacman, blinky, level)
        self.name = PINKY
        self.color = PINK
        self.sprites = GhostSprites(self)

    def chase(self):
        self.goal = self.pointAhead(PINKY_LOOKAHEAD_TILES)


class Inky(Ghost):
    def __init__(self, node, pacman=None, blinky=None, level=0):
        Ghost.__init__(self, node, pacman, blinky, level)
        self.name = INKY
        self.color = TEAL
        self.sprites = GhostSprites(self)

    def chase(self):
        ahead = self.pointAhead(INKY_LOOKAHEAD_TILES)
        if self.blinky is None:
            self.goal = ahead
            return
        vec = (ahead - self.blinky.position) * 2
        self.goal = self.blinky.position + vec

    def targetScore(self, player):
        if self.blinky is None:
            return Ghost.targetScore(self, player)
        d = (player.position - self.blinky.position).magnitude()
        return -d / self.lifeFactor(player)


class Clyde(Ghost):
    def __init__(self, node, pacman=None, blinky=None, level=0):
        Ghost.__init__(self, node, pacman, blinky, level)
        self.name = CLYDE
        self.color = ORANGE
        self.sprites = GhostSprites(self)

    def chase(self):
        d = self.pacman.position - self.position
        ds = d.magnitudeSquared()
        if ds <= (TILEWIDTH * CLYDE_SHY_DISTANCE_TILES)**2:
            self.scatter()
        else:
            self.goal = self.pacman.position.copy()


class GhostGroup(object):
    def __init__(self, node, pacman, level=0):
        players = list(pacman) if isinstance(pacman, (list, tuple)) else [pacman]
        first = players[0]
        self.blinky = Blinky(node, first, None, level)
        self.pinky = Pinky(node, first, None, level)
        self.inky = Inky(node, first, self.blinky, level)
        self.clyde = Clyde(node, first, None, level)
        self.ghosts = [self.blinky, self.pinky, self.inky, self.clyde]
        self.setPlayers(players)

    def __iter__(self):
        return iter(self.ghosts)

    def update(self, dt):
        for ghost in self:
            ghost.update(dt)

    def setPlayers(self, players):
        for ghost in self:
            ghost.setPlayers(players)

    def setPelletGroup(self, pelletGroup):
        for ghost in self:
            ghost.setPelletGroup(pelletGroup)

    def setFrozen(self, frozen):
        for ghost in self:
            ghost.setFrozen(frozen)

    def startFreight(self):
        for ghost in self:
            ghost.startFreight()
        self.resetPoints()

    def setSpawnNode(self, node):
        for ghost in self:
            ghost.setSpawnNode(node)

    def updatePoints(self):
        for ghost in self:
            ghost.points *= 2

    def resetPoints(self):
        for ghost in self:
            ghost.points = 200

    def reset(self):
        for ghost in self:
            ghost.reset()

    def hide(self):
        for ghost in self:
            ghost.visible = False

    def show(self):
        for ghost in self:
            ghost.visible = True

    def render(self, screen):
        for ghost in self:
            ghost.render(screen)
