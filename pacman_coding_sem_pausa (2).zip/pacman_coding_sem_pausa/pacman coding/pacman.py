import pygame
from pygame.locals import *
from vector import Vector2
from constants import *
from config import STARTING_LIVES
from entity import Entity
from sprites import PacmanSprites, MsPacmanSprites


DEFAULT_CONTROLS = {UP:[K_UP], DOWN:[K_DOWN], LEFT:[K_LEFT], RIGHT:[K_RIGHT]}

CHARACTER_NAMES = {PACMAN_CHAR: "PAC-MAN", MSPACMAN_CHAR: "MS.PAC-MAN"}


class Pacman(Entity):
    def __init__(self, node, controls=None, character=PACMAN_CHAR, playerId=1,
                 startDirection=LEFT, startFraction=0.5):
        Entity.__init__(self, node )
        self.name = PACMAN         
        self.directions = {STOP:Vector2(), UP:Vector2(0,-1), DOWN:Vector2(0,1), LEFT:Vector2(-1,0), RIGHT:Vector2(1,0)}
        self.direction = STOP
        self.speed = 100 * TILEWIDTH/16
        self.radius = 10
        self.color = YELLOW
        self.collideRadius = 5

        #   multiplayer

        self.playerId = playerId
        self.character = character
        self.characterName = CHARACTER_NAMES.get(character, "PAC-MAN")
        self.playerName = "P%d" % playerId
        self.controls = controls if controls is not None else DEFAULT_CONTROLS
        self.lives = STARTING_LIVES
        self.score = 0
        self.eliminated = False     
        self.pendingOut = False     
        self.respawnTimer = 0.0     # coop: tempo restante ate renascer (0 = nao esta renascendo)
        self.startDirection = startDirection
        self.startFraction = startFraction
        self.heading = startDirection   
        self.direction = startDirection
        self.setBetweenNodes(startDirection)
        self.node = node
        self.target = node
        self.alive = True
        if character == MSPACMAN_CHAR:
            self.sprites = MsPacmanSprites(self)
        else:
            self.sprites = PacmanSprites(self)
        self.reset()  

    def setPosition(self):
        self.position = self.node.position.copy()

    def setBetweenNodes(self, direction, fraction=None):
        if fraction is None:
            fraction = self.startFraction
        if self.node.neighbors[direction] is not None:
            self.target = self.node.neighbors[direction]
            self.position = self.node.position + (self.target.position - self.node.position) * fraction

    def reset(self):
        Entity.reset(self)
        self.direction = self.startDirection
        self.heading = self.startDirection
        self.setBetweenNodes(self.startDirection)
        self.alive = True
        self.respawnTimer = 0.0
        self.image = self.sprites.getStartImage()
        self.sprites.reset()

    def respawn(self):
        # Respawn individual: restaura SOMENTE este jogador (posicao, direcao, sprites,
        # controles). Nao mexe em fantasmas, mapa, pontuacao nem vidas.
        self.reset()

    def die(self):
        self.alive = False
        self.direction = STOP

    def update(self, dt):
        self.sprites.update(dt)
        if not self.alive:
            return              # morto: so anima; os controles ficam desativados ate renascer
        self.position += self.directions[self.direction]*self.speed*dt
        direction = self.getValidKey()
        if self.overshotTarget():
            self.node = self.target
            if self.node.neighbors[PORTAL] is not None:
                self.node = self.node.neighbors[PORTAL]
            self.target = self.getNewTarget(direction)
            if self.target is not self.node:
                self.direction = direction
            else:
                self.target = self.getNewTarget(self.direction)
            if self.target is self.node:
                self.direction = STOP
            self.setPosition()
        else: 
            if self.oppositeDirection(direction):
                self.reverseDirection()
        if self.direction != STOP:
            self.heading = self.direction

    def validDirection(self, direction):
        if direction is not STOP:
            if self.node.neighbors[direction] is not None:
                return True
        return False

    def getNewTarget(self, direction):
        if self.validDirection(direction):
            return self.node.neighbors[direction]
        return self.node

    def getValidKey(self):
        key_pressed = pygame.key.get_pressed()
        for direction in (UP, DOWN, LEFT, RIGHT):
            for key in self.controls[direction]:
                if key_pressed[key]:
                    return direction
        return STOP
    
    def overshotTarget(self):
        if self.target is not None:
            vec1 = self.target.position - self.node.position
            vec2 = self.position - self.node.position
            node2Target = vec1.magnitudeSquared()
            node2Self = vec2.magnitudeSquared()
            return node2Self >= node2Target
        return False
    
    def reverseDirection(self):
        self.direction *= -1
        temp = self.node
        self.node = self.target
        self.target = temp

    def oppositeDirection(self, direction):
        if direction is not STOP:
            if direction == self.direction * -1:
                return True
        return False
    
    def eatPellets(self, pelletList):
        for pellet in pelletList:
            if self.collideCheck(pellet):
                return pellet
        return None
    
    def collideGhost(self, ghost):
        return self.collideCheck(ghost)

    def collideCheck(self, other):
        d = self.position - other.position
        dSquared = d.magnitudeSquared()
        rSquared = (self.collideRadius + other.collideRadius)**2
        if dSquared <= rSquared:
            return True
        return False
