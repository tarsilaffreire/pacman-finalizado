# menu.py - tela inicial (estilo arcade), selecao de personagem e tela de resultados.

import pygame
from pygame.locals import *
from constants import *
from sprites import Spritesheet, PacmanSprites, MsPacmanSprites

FONT_PATH = "PressStart2P-Regular.ttf"
SPEED = 90.0           

MAIN_ITEMS = [
    ("JOGO SOLO",         "UM JOGADOR - ESCOLHA SEU PERSONAGEM"),
    ("MULTIPLAYER COOP",  "2 JOGADORES NO MESMO LABIRINTO"),
    ("MULTIPLAYER SPLIT", "2 JOGADORES EM LABIRINTOS SEPARADOS"),
    ("SAIR",              "FECHAR O JOGO"),
]
CHARACTERS = [(PACMAN_CHAR, "PAC-MAN"), (MSPACMAN_CHAR, "MS.PAC-MAN")]


class _Dummy(object):

    alive = True
    direction = RIGHT
    image = None


class Menu(object):
    def __init__(self):
        self.fonts = {}
        self.sheet = Spritesheet()
        self.pacSprites = PacmanSprites(_Dummy())
        self.msSprites = MsPacmanSprites(_Dummy())
        self.state = "main"         
        self.index = 0
        self.charIndex = 0
        self.time = 0.0

    # utilitarios 
    def font(self, size):
        if size not in self.fonts:
            self.fonts[size] = pygame.font.Font(FONT_PATH, size)
        return self.fonts[size]

    def drawText(self, screen, text, size, color, cx, y):
        label = self.font(size).render(text, 1, color)
        screen.blit(label, (cx - label.get_width() // 2, y))
        return label

    def ghostImage(self, ghostIndex, direction, frightened=False):
        if frightened:
            return self.sheet.getImage(10, 4, 2*TILEWIDTH, 2*TILEHEIGHT)
        return self.sheet.getImage(ghostIndex * 2, 10 if direction == RIGHT else 8, 2*TILEWIDTH, 2*TILEHEIGHT)

    def pacImage(self, sprites, direction):
        frames = {RIGHT: [(10,0), (2,0), (2,2), (2,0)], LEFT: [(8,0), (0,0), (0,2), (0,0)]}[direction]
        return sprites.getImage(*frames[int(self.time * 10) % 4])


    def reset(self):
        self.state = "main"
        self.index = 0

    def handleKey(self, key):
 
        if self.state == "main":
            if key in (K_UP, K_w):
                self.index = (self.index - 1) % len(MAIN_ITEMS)
            elif key in (K_DOWN, K_s):
                self.index = (self.index + 1) % len(MAIN_ITEMS)
            elif key in (K_RETURN, K_KP_ENTER, K_SPACE):
                if self.index == 0:
                    self.state = "character"
                    self.charIndex = 0
                elif self.index == 1:
                    return ("start", MODE_COOP, PACMAN_CHAR)
                elif self.index == 2:
                    return ("start", MODE_SPLIT, PACMAN_CHAR)
                else:
                    return ("quit",)
            elif key == K_ESCAPE:
                return ("quit",)
        else:
            if key in (K_LEFT, K_a, K_UP, K_w):
                self.charIndex = (self.charIndex - 1) % len(CHARACTERS)
            elif key in (K_RIGHT, K_d, K_DOWN, K_s):
                self.charIndex = (self.charIndex + 1) % len(CHARACTERS)
            elif key in (K_RETURN, K_KP_ENTER, K_SPACE):
                return ("start", MODE_SOLO, CHARACTERS[self.charIndex][0])
            elif key == K_ESCAPE:
                self.state = "main"
        return None

    def update(self, dt):
        self.time += dt


    def render(self, screen):
        W, H = screen.get_size()
        cx = W // 2
        screen.fill(BLACK)
        self.drawText(screen, "PACMAN", 32, YELLOW, cx, 50)
        codingColor = RED if int(self.time * 3) % 2 == 0 else (150, 0, 0)
        self.drawText(screen, "CODING", 32, codingColor, cx, 96)
        self.drawChase(screen, 190)
        if self.state == "main":
            self.renderMain(screen, cx)
        else:
            self.renderCharacter(screen, cx)

    def drawChase(self, screen, y):
        W = screen.get_width()
        span = 6 * 34 + 40
        cycle = (W + 2 * span) / SPEED
        t = self.time % (2 * cycle)
        phase = 0 if t < cycle else 1
        u = (t % cycle) * SPEED
        if phase == 0:
            lead = -span + u                      
            xs = [lead - k * 34 for k in range(6)]
            images = [self.pacImage(self.pacSprites, RIGHT), self.pacImage(self.msSprites, RIGHT)]
            images += [self.ghostImage(g, RIGHT) for g in range(4)]
            for x in range(8, W, 32):              # bolinhas ainda nao comidas
                if x > lead:
                    pygame.draw.circle(screen, WHITE, (x, y + 16), 2)
        else:
            lead = W + span - u                  
            xs = [lead + k * 34 for k in range(6)]
            images = [self.ghostImage(g, LEFT, frightened=True) for g in range(4)]
            images += [self.pacImage(self.pacSprites, LEFT), self.pacImage(self.msSprites, LEFT)]
        for x, image in zip(xs, images):
            screen.blit(image, (x - 16, y))

    def renderMain(self, screen, cx):
        W, H = screen.get_size()
        y = 270
        for i, (label, desc) in enumerate(MAIN_ITEMS):
            selected = (i == self.index)
            color = YELLOW if selected else WHITE
            self.drawText(screen, label, 16, color, cx, y)
            if selected and int(self.time * 4) % 2 == 0:
                left = self.font(16).render(">", 1, YELLOW)
                screen.blit(left, (cx - 8 * len(label) - 32, y))
            y += 40
        self.drawText(screen, MAIN_ITEMS[self.index][1], 8, TEAL, cx, 450)
        self.drawText(screen, "P1: SETAS", 8, YELLOW, cx, 520)
        self.drawText(screen, "P2: W A S D", 8, PINK_BOW, cx, 540)
        self.drawText(screen, "CIMA/BAIXO + ENTER", 8, (130, 130, 130), cx, 580)

    def renderCharacter(self, screen, cx):
        self.drawText(screen, "ESCOLHA O PERSONAGEM", 16, WHITE, cx, 270)
        positions = [cx - 112, cx + 112]
        for i, (char, name) in enumerate(CHARACTERS):
            sprites = self.pacSprites if char == PACMAN_CHAR else self.msSprites
            image = self.pacImage(sprites, RIGHT)
            big = pygame.transform.scale(image, (64, 64))
            big.set_colorkey(image.get_colorkey())
            selected = (i == self.charIndex)
            px = positions[i]
            if selected:
                pygame.draw.rect(screen, YELLOW, (px - 84, 310, 168, 150), 2)
            screen.blit(big, (px - 32, 330))
            self.drawText(screen, name, 16 if len(name) < 8 else 8, YELLOW if selected else WHITE, px, 410 if len(name) < 8 else 414)
        self.drawText(screen, "ESQUERDA/DIREITA + ENTER", 8, TEAL, cx, 490)
        self.drawText(screen, "ESC: VOLTAR", 8, (130, 130, 130), cx, 580)


    def renderResults(self, screen, worlds, mode):
        W, H = screen.get_size()
        cx = W // 2
        overlay = pygame.Surface((W, H), SRCALPHA)
        overlay.fill((0, 0, 0, 190))
        screen.blit(overlay, (0, 0))
        self.drawText(screen, "FIM DE JOGO", 32, YELLOW, cx, 160)
        players = [p for w in worlds for p in w.players]
        y = 240
        if mode == MODE_COOP:
            total = worlds[0].score
            self.drawText(screen, "PONTUACAO FINAL", 16, WHITE, cx, y)
            self.drawText(screen, str(total).zfill(8), 16, YELLOW, cx, y + 28)
            y += 80
            for p in players:
                color = YELLOW if p.playerId == 1 else PINK_BOW
                self.drawText(screen, "%s %s" % (p.playerName, p.characterName), 8, color, cx, y)
                self.drawText(screen, str(p.score).zfill(8), 8, WHITE, cx, y + 14)
                y += 40
        else:
            for p in players:
                color = YELLOW if p.playerId == 1 else PINK_BOW
                self.drawText(screen, "%s %s" % (p.playerName, p.characterName), 16, color, cx, y)
                self.drawText(screen, str(p.score).zfill(8), 16, WHITE, cx, y + 28)
                y += 80
            if len(players) == 2:
                if players[0].score > players[1].score:
                    result, rcolor = "P1 VENCEU!", YELLOW
                elif players[1].score > players[0].score:
                    result, rcolor = "P2 VENCEU!", PINK_BOW
                else:
                    result, rcolor = "EMPATE!", WHITE
                self.drawText(screen, result, 24, rcolor, cx, y + 10)
        self.drawText(screen, "ENTER: JOGAR DE NOVO", 8, WHITE, cx, 540)
        self.drawText(screen, "ESC: MENU", 8, (130, 130, 130), cx, 560)
