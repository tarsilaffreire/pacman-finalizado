
from constants import *


STARTING_LIVES = 5          # vida iniciail de cada jogador
MAX_LIVES = 5               # limite maximo de vida
PLAYER_RESPAWN_DELAY = 3.0  # coop: segundos entre a morte e o respawn individual do jogador


# powerups q o professor pediu

POWERUP_SPAWN_CHANCE = 0.10     # chance (0 a 10%) de surgir um item a cada bolinha coletada
POWERUP_TYPE_WEIGHTS = {        
    HEART_ITEM: 1.0,
    FREEZE_ITEM: 1.0,
}
POWERUP_MIN_INTERVAL = 8.0     
POWERUP_LIFETIME = 10.0        
POWERUP_BLINK_TIME = 3.0       
POWERUP_MAX_ACTIVE = 2          
POWERUP_MIN_ITEM_DISTANCE = 4   
POWERUP_MIN_PLAYER_DISTANCE = 3 

FREEZE_DURATION = 5.0           # tempo que os fantasmas ficam congelados 
HEART_LIVES_GAINED = 1          # vidas recuperadas pelo coracao
POWERUP_POINTS = {HEART_ITEM: 0, FREEZE_ITEM: 0}   


# ia dos  fantasmas  igual do original  (usei ia  para  fazer)


MODE_SCHEDULE = [(SCATTER, 7), (CHASE, 20), (SCATTER, 7), (CHASE, 20),
                 (SCATTER, 5), (CHASE, 20), (SCATTER, 5), (CHASE, None)]
SCATTER_REDUCTION_PER_LEVEL = 0.5   
SCATTER_MIN_TIME = 2.0
CHASE_BONUS_PER_LEVEL = 2.0         


SCATTER_TARGETS = {
    BLINKY: (NCOLS - 3, 0),         # canto superior direito
    PINKY:  (2, 0),                 # canto superior esquerdo
    INKY:   (NCOLS - 1, NROWS),     # canto inferior direito
    CLYDE:  (0, NROWS),             # canto inferior esquerdo
}

PINKY_LOOKAHEAD_TILES = 4       # Pinky mira 4 tiles a frente do jogador
INKY_LOOKAHEAD_TILES = 2        # Inky usa o ponto 2 tiles a frente e o vetor do Blinky
CLYDE_SHY_DISTANCE_TILES = 8    # Clyde foge para o canto quando chega mais perto que isso

# Blinky: agressividade crescente ("Cruise Elroy")
BLINKY_SPEED_BONUS_PER_LEVEL = 0.03     # +3% de velocidade por fase
BLINKY_MAX_LEVEL_BONUS = 0.20           # teto do bonus por fase
BLINKY_ELROY_1_PELLETS = 20             # bolinhas restantes para o 1o aumento
BLINKY_ELROY_2_PELLETS = 10             # bolinhas restantes para o 2o aumento
BLINKY_ELROY_1_BONUS = 0.05
BLINKY_ELROY_2_BONUS = 0.10

# escolha de alvo com dois jogadores
TARGET_RECHECK_TIME = 0.5       # de quanto em quanto tempo o fantasma reavalia o alvo
TARGET_LIFE_WEIGHT = 0.05       # quanto menos vidas, mais "atraente" o jogador (peso por vida)
TARGET_SWITCH_MARGIN = 0.85     # so troca de alvo se o novo for 15% melhor (evita tremedeira)

# anti-travamento: detecta fantasma andando em circulos durante o CHASE
LOOP_HISTORY = 14               # quantas decisoes de direcao sao observadas
LOOP_MAX_UNIQUE_NODES = 3       # <= isso de nos distintos = esta em loop
LOOP_COOLDOWN = 3.0             # tempo ate permitir outra correcao


HUD_HEIGHT = 72                 # altura da faixa de status abaixo do labirinto
HUD_MESSAGE_TIME = 2.0          # quanto tempo mensagens do tipo "+1 VIDA" ficam visiveis
