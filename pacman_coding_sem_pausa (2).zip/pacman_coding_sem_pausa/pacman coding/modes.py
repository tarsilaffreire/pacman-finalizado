from constants import *
from config import (MODE_SCHEDULE, SCATTER_REDUCTION_PER_LEVEL, SCATTER_MIN_TIME,
                    CHASE_BONUS_PER_LEVEL)

class MainMode(object):

    def __init__(self, level=0):
        self.level = level
        self.schedule = self.buildSchedule(level)
        self.index = 0
        self.timer = 0
        self.mode = None
        self.time = None
        self.applyStep()

    @staticmethod
    def buildSchedule(level):
        steps = []
        for mode, duration in MODE_SCHEDULE:
            if duration is not None:
                if mode == SCATTER:
                    duration = max(SCATTER_MIN_TIME, duration - SCATTER_REDUCTION_PER_LEVEL * level)
                else:
                    duration = duration + CHASE_BONUS_PER_LEVEL * level
            steps.append((mode, duration))
        return steps

    def applyStep(self):
        self.mode, self.time = self.schedule[self.index]
        self.timer = 0

    def update(self, dt):
        self.timer += dt
        if self.time is not None and self.timer >= self.time:
            if self.index < len(self.schedule) - 1:
                self.index += 1
                self.applyStep()

    def scatter(self):
        self.mode = SCATTER

    def chase(self):
        self.mode = CHASE


class ModeController(object):
    def __init__(self, entity, level=0):
        self.timer = 0
        self.time = None
        self.mainmode = MainMode(level)
        self.current = self.mainmode.mode
        self.entity = entity 

    def update(self, dt):
        self.mainmode.update(dt)
        if self.current is FREIGHT:
            self.timer += dt
            if self.timer >= self.time:
                self.time = None
                self.entity.normalMode()
                self.current = self.mainmode.mode
        elif self.current in [SCATTER, CHASE]:
            self.current = self.mainmode.mode

        if self.current is SPAWN:
            if self.entity.node == self.entity.spawnNode:
                self.entity.normalMode()
                self.current = self.mainmode.mode

    def setSpawnMode(self):
        if self.current is FREIGHT:
           self.current = SPAWN

    def setFreightMode(self):
        if self.current in [SCATTER, CHASE]:
            self.timer = 0
            self.time = 7
            self.current = FREIGHT
        elif self.current is FREIGHT:
            self.timer = 0
