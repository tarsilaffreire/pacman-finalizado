import os
import sys
import pygame
from pygame.locals import *
from constants import *
from config import *
from world import GameWorld, PlayerSlot, P1_CONTROLS, P2_CONTROLS, SOLO_CONTROLS
from hud import HUD
from menu import Menu


os.chdir(os.path.dirname(os.path.abspath(__file__)))

FPS = 60                    
MAX_DT = 1.0 / 20.0         
STATE_MENU = 0
STATE_PLAYING = 1
STATE_RESULTS = 2
RESULTS_DELAY = 3.0         


class GameController(object):
    """
    Controlador da aplicacao: menu -> partida -> resultados.
    A logica de cada labirinto fica em world.GameWorld (1 mundo no solo/coop,
    2 mundos independentes no modo de mapas separados).
    """
    def __init__(self):
        pygame.init()
        pygame.display.set_caption("Pacman Coding")
        self.clock = pygame.time.Clock()
        self.screen = None
        self.setWindow(SCREENWIDTH, SCREENHEIGHT + HUD_HEIGHT)
        self.menu = Menu()
        self.hud = HUD()
        self.state = STATE_MENU
        self.mode = None
        self.character = PACMAN_CHAR
        self.worlds = []
        self.userPaused = False
        self.resultsTimer = 0.0

    def setWindow(self, width, height):
        if self.screen is None or self.screen.get_size() != (width, height):
            self.screen = pygame.display.set_mode((width, height), 0, 32)


#aqui começa a partida
    
    def startMode(self, mode, character=PACMAN_CHAR):
        self.mode = mode
        self.character = character
        p1 = PlayerSlot(1, "P1", PACMAN_CHAR, P1_CONTROLS)
        p2 = PlayerSlot(2, "P2", MSPACMAN_CHAR, P2_CONTROLS)
        if mode == MODE_SOLO:
            solo = PlayerSlot(1, "P1", character, SOLO_CONTROLS)
            self.setWindow(SCREENWIDTH, SCREENHEIGHT + HUD_HEIGHT)
            self.worlds = [GameWorld([solo], autoRestart=True)]
        elif mode == MODE_COOP:
            self.setWindow(SCREENWIDTH, SCREENHEIGHT + HUD_HEIGHT)
            self.worlds = [GameWorld([p1, p2])]
        else:
            self.setWindow(SCREENWIDTH * 2, SCREENHEIGHT + HUD_HEIGHT)
            self.worlds = [GameWorld([p1], individualRespawn=True), GameWorld([p2], individualRespawn=True)]
        for world in self.worlds:
            world.startGame()
        self.userPaused = False
        self.resultsTimer = 0.0
        self.state = STATE_PLAYING

    def backToMenu(self):
        self.worlds = []
        self.setWindow(SCREENWIDTH, SCREENHEIGHT + HUD_HEIGHT)
        self.menu.reset()
        self.state = STATE_MENU

    def rematch(self):
        self.startMode(self.mode, self.character)

    def quit(self):
        pygame.quit()
        sys.exit()

   
   
    
    def update(self):
        dt = min(self.clock.tick(FPS) / 1000.0, MAX_DT)
        if self.state == STATE_MENU:
            self.menu.update(dt)
            self.checkEvents()
            self.menu.render(self.screen)
            pygame.display.update()
        elif self.state == STATE_PLAYING:
            for world in self.worlds:
                world.update(dt)
            self.checkGameEnd(dt)
            self.checkEvents()
            self.render()
        else:
            self.menu.update(dt)
            self.checkEvents()
            self.render()
            self.menu.renderResults(self.screen, self.worlds, self.mode)
            pygame.display.update()

    def checkGameEnd(self, dt):
        if all(world.finished for world in self.worlds):
            self.resultsTimer += dt
            if self.resultsTimer >= RESULTS_DELAY:
                self.state = STATE_RESULTS
        else:
            self.resultsTimer = 0.0

    def checkEvents(self):
        for event in pygame.event.get():
            if event.type == QUIT:
                self.quit()
            elif event.type == KEYDOWN:
                if self.state == STATE_MENU:
                    action = self.menu.handleKey(event.key)
                    if action is not None:
                        if action[0] == "quit":
                            self.quit()
                        elif action[0] == "start":
                            self.startMode(action[1], action[2])
                            return
                elif self.state == STATE_RESULTS:
                    if event.key in (K_RETURN, K_KP_ENTER, K_SPACE):
                        self.rematch()
                        return
                    elif event.key == K_ESCAPE:
                        self.backToMenu()
                        return
                else:
                    if event.key == K_ESCAPE:
                        self.backToMenu()
                        return
                    elif event.key == K_SPACE:
                        self.handleSpace()

    def handleSpace(self):
        """ESPACO: inicia/continua ('READY!') e pausa/despausa o jogo."""
        waiting = [w for w in self.worlds if w.isWaiting()]
        if waiting:
            for world in waiting:
                world.resume()
            return
        self.userPaused = not self.userPaused
        for world in self.worlds:
            if self.userPaused:
                world.setUserPaused(True)
            elif world.userPaused:
                world.setUserPaused(False)
        if self.userPaused and not any(w.userPaused for w in self.worlds):
            self.userPaused = False        # nada podia ser pausado agora

   
  
    
    def render(self):
        self.screen.fill(BLACK)
        for i, world in enumerate(self.worlds):
            surface = world.render()
            self.screen.blit(surface, (i * SCREENWIDTH, 0))
        hudY = SCREENHEIGHT
        if self.mode == MODE_SPLIT:
            for i, world in enumerate(self.worlds):
                self.hud.drawPanel(self.screen, (i * SCREENWIDTH, hudY, SCREENWIDTH, HUD_HEIGHT), world, world.players[0])
            pygame.draw.line(self.screen, (40, 40, 200), (SCREENWIDTH - 1, 0), (SCREENWIDTH - 1, SCREENHEIGHT + HUD_HEIGHT), 2)
        else:
            world = self.worlds[0]
            count = len(world.players)
            panelW = SCREENWIDTH // count
            for i, player in enumerate(world.players):
                self.hud.drawPanel(self.screen, (i * panelW, hudY, panelW, HUD_HEIGHT), world, player)
            if count > 1:
                pygame.draw.line(self.screen, (40, 40, 200), (panelW - 1, hudY), (panelW - 1, hudY + HUD_HEIGHT), 2)
        if self.state == STATE_PLAYING:
            pygame.display.update()

    
if __name__ == "__main__":
    game = GameController()
    while True:
        game.update()
