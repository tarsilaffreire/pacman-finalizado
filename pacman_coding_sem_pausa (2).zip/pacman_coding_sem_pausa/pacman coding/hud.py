import pygame
from constants import *
from config import *
from powerups import PowerUpArt

FONT_PATH = "PressStart2P-Regular.ttf"
PLAYER_COLORS = {1: YELLOW, 2: PINK_BOW}
PANEL_BG = (6, 6, 28)
DIM = (110, 110, 140)


class HUD(object):
    def __init__(self):
        self.font = pygame.font.Font(FONT_PATH, 8)
        self.textCache = {}
        self.lifeIcons = {}
        self.effectIcon = None

    def text(self, string, color):
        key = (string, color)
        surf = self.textCache.get(key)
        if surf is None:
            if len(self.textCache) > 400:
                self.textCache.clear()
            surf = self.font.render(string, 1, color)
            self.textCache[key] = surf
        return surf

    def lifeIcon(self, player):
        key = (player.character, player.playerId)
        icon = self.lifeIcons.get(key)
        if icon is None:
            image = player.sprites.getImage(2, 0)      
            icon = pygame.transform.scale(image, (16, 16))
            icon.set_colorkey(image.get_colorkey())
            self.lifeIcons[key] = icon
        return icon

    def freezeIcon(self):
        if self.effectIcon is None:
            self.effectIcon = pygame.transform.smoothscale(PowerUpArt.get(FREEZE_ITEM), (14, 14))
        return self.effectIcon

    def drawPanel(self, screen, rect, world, player):
        x, y, w, h = rect
        color = PLAYER_COLORS.get(player.playerId, WHITE)
        pygame.draw.rect(screen, PANEL_BG, rect)
        pygame.draw.line(screen, color, (x, y), (x + w - 1, y), 2)

        screen.blit(self.text("%s %s" % (player.playerName, player.characterName), color), (x + 6, y + 6))
        if player.eliminated or (player.pendingOut and not player.alive):
            label = self.text("ELIMINADO", RED)
            screen.blit(label, (x + w - label.get_width() - 6, y + 6))

        icon = self.lifeIcon(player)
        for i in range(min(player.lives, MAX_LIVES)):
            screen.blit(icon, (x + 6 + i * 18, y + 20))
        score = self.text(str(player.score).zfill(8), WHITE)
        screen.blit(score, (x + w - score.get_width() - 6, y + 24))

        cy = y + 42
        if world.freezeTimer > 0 and world.freezeOwner is not None:
            owner = world.freezeOwner
            ocolor = PLAYER_COLORS.get(owner.playerId, WHITE)
            screen.blit(self.freezeIcon(), (x + 6, cy - 3))
            label = "%s CONGELA %.1fS" % (owner.playerName, world.freezeTimer)
            screen.blit(self.text(label, ICE_BLUE if owner is player else ocolor), (x + 24, cy))
            frac = max(0.0, min(1.0, world.freezeTimer / FREEZE_DURATION))
            barw = w - 12
            pygame.draw.rect(screen, (30, 40, 80), (x + 6, cy + 11, barw, 4))
            pygame.draw.rect(screen, ICE_BLUE, (x + 6, cy + 11, int(barw * frac), 4))
        else:
            screen.blit(self.text("SEM EFEITOS", DIM), (x + 6, cy))

        if not player.alive and player.respawnTimer > 0 and not player.pendingOut and not player.eliminated:
            screen.blit(self.text("RENASCE %.1fS" % player.respawnTimer, WHITE), (x + 6, y + 60))
            return
        msg = world.messages.get(player.playerId)
        if msg is not None:
            screen.blit(self.text(msg[0], msg[1]), (x + 6, y + 60))
